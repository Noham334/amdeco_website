﻿Imports Microsoft.Office.Interop  ' libreria que permite exportar a EXCEL

Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        For i As Integer = 0 To 2
            DataGridView1.Rows.Add(i, "21/11/2011", Month(Now), "Disco duro", "Dispositivos", 2 + i, Format((1 + i) * 120000, "N0"))
        Next

        For i As Integer = 0 To 2
            DataGridView1.Rows.Add(i, "18/10/2011", "10", "Memorias", "Dispositivos", 2 + i, Format((1 + i) * 60000, "N0"))
        Next

        For i As Integer = 0 To 2
            DataGridView1.Rows.Add(i, "10/11/2011", "11", "Procesador", "Dispositivos", 2 + i, Format((1 + i) * 140000, "N0"))
        Next



        'centra la cantidad 
        DataGridView1.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.BottomCenter
        'justifica el valor a la izquierda
        DataGridView1.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

        'Total items
        Ttitems.Text = DataGridView1.RowCount - 1

        'Suma la  cantidad & valor
        Dim Scantidad, Svalor As Integer
        For i As Integer = 0 To DataGridView1.RowCount - 1
            Scantidad += DataGridView1.Rows(i).Cells(5).Value
            Svalor += DataGridView1.Rows(i).Cells(6).Value
        Next
        Ttcantidad.Text = Format(Scantidad, "N0") 'Muestro la suma en el label ttcantidad con formato numerico
        Ttotal.Text = Format(Svalor, "N0") 'Muestro la suma en el label ttotal con formato numerico

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Form2.Show()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim exApp As New Microsoft.Office.Interop.Excel.Application
        Dim exLibro As Microsoft.Office.Interop.Excel.Workbook
        Dim exHoja As Microsoft.Office.Interop.Excel.Worksheet

        Try

            'Añadimos el Libro al programa, y la hoja al libro
            exLibro = exApp.Workbooks.Add
            exHoja = exLibro.Worksheets.Add()

            ' ¿Cuantas columnas y cuantas filas?
            Dim NCol As Integer = DataGridView1.ColumnCount
            Dim NRow As Integer = DataGridView1.RowCount



            exHoja.Cells.Item(1, 1) = "solucionespc1@hotmail.com"
            exHoja.Cells.Item(2, 1) = "NIT: xxxx "
            exHoja.Cells.Item(3, 1) = "FECHA : " & DateString

            exHoja.Cells.Item(5, 1) = "Codigo"
            exHoja.Cells.Item(5, 2) = "Fecha"
            exHoja.Cells.Item(5, 3) = "Mes"
            exHoja.Cells.Item(5, 4) = "Producto"
            exHoja.Cells.Item(5, 5) = "Categoria"
            exHoja.Cells.Item(5, 6) = "Cantidad"
            exHoja.Cells.Item(5, 7) = "Valor"





            Dim posicion As Integer = 1
            For Fila As Integer = 0 To NRow - 1
                For Col As Integer = 0 To NCol - 1
                    exHoja.Cells.Item(Fila + 6, Col + 1) = DataGridView1.Rows(Fila).Cells(Col).Value 'fila 7ubicacion de los datos
                Next
            Next

            'pone en negrita los titulos
            exHoja.Rows.Item(5).Font.Bold = 6




            'Aplicación visible
            exApp.Application.Visible = True

            exHoja = Nothing
            exLibro = Nothing
            exApp = Nothing

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error al exportar a Excel")
            '    Return False
        End Try

        'Return True

    End Sub
End Class
