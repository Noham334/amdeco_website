﻿Public Class Form2

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try

        
        DataGridView1.Rows.Clear() 'limpia el datagri


        Dim CD, FC, MS, PR, CT, CTD, VL As String 'Variables q van almacenar cada unos de los campos a pasar del formulario1
        For fila As Integer = 0 To Form1.DataGridView1.RowCount - 1 'cuenta el numero de fila datagri delformulario 1
            If Form1.DataGridView1.Rows(fila).Cells(2).Value = ComboBox1.Text Then 'compara si fila de la columna 2 es igual al mes pasa la informacion
                CD = Form1.DataGridView1.Rows(fila).Cells(0).Value 'valor fila columna cero
                FC = Form1.DataGridView1.Rows(fila).Cells(1).Value 'valor fila columna uno
                MS = Form1.DataGridView1.Rows(fila).Cells(2).Value 'valor fila columna dos
                PR = Form1.DataGridView1.Rows(fila).Cells(3).Value 'valor fila columna tres
                CT = Form1.DataGridView1.Rows(fila).Cells(4).Value 'valor fila columna cuatro
                CTD = Form1.DataGridView1.Rows(fila).Cells(5).Value 'valor fila columna cinco
                VL = Form1.DataGridView1.Rows(fila).Cells(6).Value 'valor fila columna seis
                    DataGridView1.Rows.Add(CD, FC, MS, PR, CT, CTD, VL) 'asqui carga la informacion al datagrid del formulario 2


            End If
        Next

        totales() 'proceso que calcula los totales de las cantidades y los valores 




        Catch ex As Exception
        End Try

    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'este bucle nos carga los meses el combobox1
        For i As Integer = 0 To 12
            ComboBox1.Items.Add(i)
        Next

        'lleno el combobox2 con estas fechas para luego utilizarlas
        ComboBox2.Items.Add("21/11/2011")
        ComboBox2.Items.Add("10/11/2011")
        ComboBox2.Items.Add("18/10/2011")


        'lleno el combobox3 con los nombres de los tres productos para luego hacer busqueda
        ComboBox3.Items.Add("Disco duro")
        ComboBox3.Items.Add("Memorias")
        ComboBox3.Items.Add("Procesador")




    End Sub

    

  

    
    Private Sub ComboBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged

    End Sub

    Private Sub ComboBox3_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox3.TextChanged
        DataGridView1.Rows.Clear() 'limpia el datagri
        DataGridView1.Rows(0).Cells(3).Value = ComboBox3.Text 'hacer clic en combobox me escribe su valor el datagrid en la posicio cero de columna 3

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    

    Sub totales()
        'Suma la  cantidad & valor
        Dim Scantidad, Svalor As Integer
        For i As Integer = 0 To DataGridView1.RowCount - 1 'cuenta el numero de filas q tiene el datagrid del formulario 2
            Scantidad += DataGridView1.Rows(i).Cells(5).Value 'suma las cantidades y las va acomulando en la variable scantidad
            Svalor += DataGridView1.Rows(i).Cells(6).Value 'suma las cantidades y las va acomulando en la variable svalor
        Next
        Ttcantidad.Text = Format(Scantidad, "N0") 'Muestro la suma en el label ttcantidad con formato numerico
        Ttotal.Text = Format(Svalor, "N0") 'Muestro la suma en el label ttotal con formato numerico

    End Sub

  
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try


            DataGridView1.Rows.Clear() 'limpia el datagri


            Dim CD, FC, MS, PR, CT, CTD, VL As String 'Variables q van almacenar cada unos de los campos a pasar del formulario1
            For fila As Integer = 0 To Form1.DataGridView1.RowCount - 1 'cuenta el numero de fila datagri delformulario 1
                If Form1.DataGridView1.Rows(fila).Cells(1).Value = ComboBox2.Text Then 'compara si fila de la columna 1 es igual al mes pasa la informacion
                    CD = Form1.DataGridView1.Rows(fila).Cells(0).Value 'valor fila columna cero
                    FC = Form1.DataGridView1.Rows(fila).Cells(1).Value 'valor fila columna uno
                    MS = Form1.DataGridView1.Rows(fila).Cells(2).Value 'valor fila columna dos
                    PR = Form1.DataGridView1.Rows(fila).Cells(3).Value 'valor fila columna tres
                    CT = Form1.DataGridView1.Rows(fila).Cells(4).Value 'valor fila columna cuatro
                    CTD = Form1.DataGridView1.Rows(fila).Cells(5).Value 'valor fila columna cinco
                    VL = Form1.DataGridView1.Rows(fila).Cells(6).Value 'valor fila columna seis
                    DataGridView1.Rows.Add(CD, FC, MS, PR, CT, CTD, VL) 'asqui carga la informacion al datagrid del formulario 2
                End If
            Next

            totales() 'proceso que calcula los totales de las cantidades y los valores 

        Catch ex As Exception
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try



            DataGridView1.Rows.Clear() 'limpia el datagri


            Dim fila, CD, FC, MS, PR, CT, CTD, VL As String 'Variables q van almacenar cada unos de los campos a pasar del formulario1

            fila = Form1.DataGridView1.CurrentRow.Index 'a la variable fila la asigno el index o fila seleccionada del datagrid del formulario 1

            CD = Form1.DataGridView1.Rows(fila).Cells(0).Value 'valor fila columna cero
            FC = Form1.DataGridView1.Rows(fila).Cells(1).Value 'valor fila columna uno
            MS = Form1.DataGridView1.Rows(fila).Cells(2).Value 'valor fila columna dos
            PR = Form1.DataGridView1.Rows(fila).Cells(3).Value 'valor fila columna tres
            CT = Form1.DataGridView1.Rows(fila).Cells(4).Value 'valor fila columna cuatro
            CTD = Form1.DataGridView1.Rows(fila).Cells(5).Value 'valor fila columna cinco
            VL = Form1.DataGridView1.Rows(fila).Cells(6).Value 'valor fila columna seis

            DataGridView1.Rows.Add(CD, FC, MS, PR, CT, CTD, VL) 'asqui carga la informacion al datagrid del formulario 2
            Form1.DataGridView1.Rows.Remove(Form1.DataGridView1.CurrentRow) 'Borra la fila selecciona del datagrid 1 formulario 1

            totales() 'proceso que calcula los totales de las cantidades y los valores 

        Catch ex As Exception
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try





            Dim cantidad, valor As Integer 'variables q van a contener la sumatoria de las cantidades y el valor


            For fila As Integer = 0 To Form1.DataGridView1.RowCount - 1 'cuenta el numero de fila datagri delformulario 1
                If Form1.DataGridView1.Rows(fila).Cells(3).Value = ComboBox3.Text Then 'compara si fila de la columna 3 es igual al mes pasa la informacion
                    cantidad += Form1.DataGridView1.Rows(fila).Cells(5).Value 'le asigno el valor fila de la columna 5 q es la cantidad a la variable cantidad
                    valor += Form1.DataGridView1.Rows(fila).Cells(6).Value 'le asigno el valor fila de la columna 6 q es el valor  a la variable valor
                End If
            Next

            DataGridView1.Rows(0).Cells(5).Value = Format(cantidad, "N0") 'pongo en el datagri en fila cero de la columna 5 del formulario 2 los valores q cotiene la variable cantidad
            DataGridView1.Rows(0).Cells(6).Value = Format(valor, "N0")  'pongo en el datagri en fila cero de la columna 6  formulario 2 los valores q cotiene la variable valor


            totales() 'proceso que calcula los totales de las cantidades y los valores 

        Catch ex As Exception
        End Try

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Try


            DataGridView1.Rows.Clear() 'limpia el datagri

            DataGridView1.Rows.Add(1, "", "", "Disco duro") 'agrego los productos al datagrid para el ejemplo
            DataGridView1.Rows.Add(2, "", "", "Memorias")
            DataGridView1.Rows.Add(3, "", "", "Procesador")



            Dim cantidad, valor As Integer  'variables q van a contener la sumatoria de las cantidades y el valor
            Dim productof1, productof2 As String  'variables q van a contener la sumatoria de las cantidades y el valor


            For i As Integer = 0 To DataGridView1.RowCount - 2 'cuenta el numero filas del datagerid del formulario2
                productof2 = DataGridView1.Rows(i).Cells(3).Value 'variable producto del datagrid del formulario 2
                cantidad = 0 'incio las variables en cero cada vez q pasa un ciclo para que no me acomule el valor del producto anterior
                valor = 0
                For fila As Integer = 0 To Form1.DataGridView1.RowCount - 1 'cuenta el numero de fila datagri delformulario 1
                    productof1 = Form1.DataGridView1.Rows(fila).Cells(3).Value 'variable producto del datagrid del formulario 1
                    If productof1 = productof2 Then 'compara si fila de la columna 3 es igual al mes pasa la informacion
                        cantidad += Form1.DataGridView1.Rows(fila).Cells(5).Value 'le asigno el valor fila de la columna 5 q es la cantidad a la variable cantidad
                        valor += Form1.DataGridView1.Rows(fila).Cells(6).Value 'le asigno el valor fila de la columna 6 
                        DataGridView1.Rows(i).Cells(5).Value = Format(cantidad, "N0") 'asigno las cantidades y los valores a los producto del datagrid 1 del formulario 1
                        DataGridView1.Rows(i).Cells(6).Value = Format(valor, "N0")
                    End If
                Next
            Next

            totales() 'proceso que calcula los totales de las cantidades y los valores 

        Catch ex As Exception
        End Try

    End Sub
End Class
